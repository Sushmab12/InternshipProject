<?php session_start();?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
		<?php
			include("includes/head.inc.php");
		?>
</head>

<body>
			<!-- start header -->
				<div id="header">
					<div id="menu">
						<?php
							include("includes/menu.inc.php");
						?>
					</div>
				</div>
				
				<div id="logo-wrap">
					<div id="logo">
							<?php
								include("includes/logo.inc.php");
							?>
					</div>
				</div>
			<!-- end header -->
			
			<!-- start page -->

				<div id="page">
					<!-- start content -->
					<div id="content">
						<div class="post">
							<h1 class="title">About Us</h1>
							<div class="entry" style="height:auto">
							
							<br>
							<img src="upload_image/wonderful-book-wallpaper-41796-42778-hd-wallpapers.JPG" width="200" height="100"><br/>
							
							<br>
								
The goal of this master's project is to design an online bookstore named Techbook.com that mainly sells computer and technical books.<br/>
 The book inventories are stored in Oracle database in UB.
 Customers can access the bookstore web site through the World Wide Web. 
 <br/>Customers will be able to search the database to find the books 
 they want, check the availability, and place the order to buy the book using their credit cards.<br/>
 
This bookstore also provide a software bridge to two real commercial online bookstores: Bookpools.com and Fatbrain.com. 
This bridge allow customer to search the inventory of these real bookstores, and display the searching results such as the title ,
 the price and availability of the book.

							</div>
							
						</div>
						
					</div>
					<!-- end content -->
					
					<!-- start sidebar -->
					<div id="sidebar">
							<?php
								include("includes/search.inc.php");
							?>
					</div>
					<!-- end sidebar -->
					<div style="clear: both;">&nbsp;</div>
				</div>
			<!-- end page -->
			
			<!-- start footer -->
				<div id="footer">
							<?php
								include("includes/footer.inc.php");
							?>
				</div>
			<!-- end footer -->
</body>
</html>
